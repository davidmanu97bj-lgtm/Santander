# EXPLORA APK - proyecto Android WebView

Este proyecto genera una app Android llamada **EXPLORA** que abre directamente:

https://davidmanu97bj-lgtm.github.io/santander/

## Cómo compilar APK

1. Abrir esta carpeta en Android Studio.
2. Esperar que sincronice Gradle.
3. Ir a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El APK queda en: `app/build/outputs/apk/debug/app-debug.apk`.
5. Pasar ese APK al Redmi por WhatsApp/Drive y aceptar instalación desde fuentes desconocidas.

## Importante

- Es una app WebView: no copia toda la web adentro, carga la versión publicada de GitHub Pages.
- Incluye permisos de internet, cámara y selección de imágenes para comprobantes/fotos.
- Si querés publicar una versión formal, conviene firmar un APK release.
